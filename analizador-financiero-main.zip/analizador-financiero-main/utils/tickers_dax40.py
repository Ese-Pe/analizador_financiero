# utils/tickers_dax40.py
# DAX 40 (Alemania) - Top 30 por liquidez
symbols_dax40 = [
    "SAP.DE", "SIE.DE", "ALV.DE", "DTE.DE", "VOW3.DE", "MBG.DE",
    "BMW.DE", "BAS.DE", "MUV2.DE", "AIR.DE", "ADS.DE", "DB1.DE",
    "DBK.DE", "IFX.DE", "HEN3.DE", "RWE.DE", "BEI.DE", "HNR1.DE",
    "CON.DE", "VNA.DE", "FRE.DE", "PAH3.DE", "ZAL.DE", "PUM.DE",
    "MTX.DE", "HEI.DE", "QIA.DE", "SHL.DE", "1COV.DE", "ENR.DE"
]
