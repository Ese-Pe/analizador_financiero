# Lista de tickers del EURO STOXX 50
symbols_stoxx = [
    "AIR.PA", "ALV.DE", "ASML.AS", "BNP.PA", "DAI.DE", "DTE.DE", "ENEL.MI",
    "IBE.MC", "MC.PA", "OR.PA", "RACE.MI", "RMS.PA", "SAN.MC", "SAP.DE",
    "SIE.DE", "SU.PA", "TTE.PA", "VOW3.DE", "ITX.MC", "BBVA.MC", "AD.AS",
    "BAS.DE", "AXA.PA", "SGO.PA", "ISP.MI", "AIR.DE", "CS.PA", "KER.PA",
    "ENGI.PA", "PHIA.AS"
]
