# 📊 Swing Trading Analyzer

Sistema automatizado de análisis técnico para swing trading (3-5 días), optimizado para capital de €2k-€5k con stop loss ajustado al 1%.

## 🎯 Características

- ✅ **Score ultra-preciso**: Sistema de puntuación 0-10 con 7 indicadores técnicos
- ✅ **Filtros estrictos**: Solo señales 8+/10 con ratio riesgo/beneficio > 5:1
- ✅ **Doble informe**: Análisis detallado (Viernes) + Actualización (Lunes)
- ✅ **Stop loss dinámico**: Basado en ATR y SuperTrend (1%)
- ✅ **300+ activos**: S&P500, NASDAQ100, STOXX50, DAX40, ETFs sectoriales
- ✅ **100% Gratis**: GitHub Actions + Yahoo Finance

## 📈 Indicadores Técnicos

### Principales
- **RSI(9)**: Sobreventa/sobrecompra (más reactivo que RSI 14)
- **Stochastic(9,3,3)**: Confirmación de sobreventa + cruce alcista
- **MACD(5,13,5)**: Momentum rápido para swing trading
- **EMAs(5,20,50)**: Tendencias de corto y medio plazo

### Complementarios
- **ADX(14)**: Fuerza de la tendencia (mín. 25)
- **ATR(7)**: Volatilidad para stop loss dinámico
- **Keltner Channels**: Niveles de soporte/resistencia
- **SuperTrend**: Stop loss inteligente
- **VWAP**: Precio promedio ponderado por volumen

## 🚀 Instalación

### 1. Clonar repositorio
```bash
git clone https://github.com/tu-usuario/swing-trading-analyzer.git
cd swing-trading-analyzer
```

### 2. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 3. Configurar Telegram

#### Obtener Token del Bot
1. Habla con [@BotFather](https://t.me/botfather) en Telegram
2. Crea un bot: `/newbot`
3. Copia el token: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`

#### Obtener Chat ID
1. Habla con [@userinfobot](https://t.me/userinfobot)
2. Copia tu ID: `123456789`

#### Configurar variables de entorno

**Linux/Mac:**
```bash
export TELEGRAM_TOKEN="tu_token_aqui"
export TELEGRAM_CHAT_ID="tu_chat_id_aqui"
```

**Windows:**
```cmd
set TELEGRAM_TOKEN=tu_token_aqui
set TELEGRAM_CHAT_ID=tu_chat_id_aqui
```

### 4. Probar el sistema
```bash
python test_system.py
```

Deberías ver:
```
✅ PASS - Configuración
✅ PASS - Telegram
✅ PASS - Tickers
✅ PASS - Análisis
🎯 Total: 4/4 tests pasados
```

## 📅 Uso

### Ejecución manual

**Informe detallado (Viernes):**
```bash
python orchestrator.py detailed
```

**Actualización rápida (Lunes):**
```bash
python orchestrator.py update
```

### Ejecución automática (GitHub Actions)

1. Ve a tu repositorio en GitHub
2. Settings → Secrets and variables → Actions
3. Añade dos secrets:
   - `TELEGRAM_TOKEN`: Tu token del bot
   - `TELEGRAM_CHAT_ID`: Tu chat ID
4. El sistema se ejecutará automáticamente:
   - **Viernes 19:00 CET**: Informe detallado
   - **Lunes 09:00 CET**: Actualización

## 📊 Ejemplo de Informe

### Viernes (Detallado)
```
📊 INFORME SEMANAL - VIERNES
🕐 15/11/2024 18:00 UTC
══════════════════════════════════════

📈 RESUMEN EJECUTIVO
────────────────────────────────────
🎯 Oportunidades detectadas: 3
🟢 Señales MUY FUERTES: 2
⭐ Score promedio: 8.6/10
💎 Ratio R/R promedio: 6.2:1

══════════════════════════════════════
ANÁLISIS DETALLADO
══════════════════════════════════════

🟢 1. AAPL - Score: 8.9/10
────────────────────────────────────
📍 🎯 Rebote alcista PREMIUM (MUY FUERTE)
💰 Precio actual: $178.50

🎯 PLAN DE ENTRADA:
  ├─ Entrada óptima: $176.80
  ├─ Entrada máxima: $178.50
  └─ 💡 Mejor momento: Lunes apertura

🛡️ GESTIÓN DE RIESGO:
  └─ Stop Loss: $176.72 (-1.0%)

🎁 OBJETIVOS DE BENEFICIO:
  ├─ Target 1: $185.20 (+3.8%) - R/R 3.8:1
  ├─ Target 2: $191.00 (+7.0%) - R/R 7.0:1 ⭐
  └─ Target 3: $196.35 (+10.0%) - R/R 10.0:1

📊 INDICADORES TÉCNICOS:
  ├─ RSI(9): 24 | Stoch: 18
  ├─ ADX: 32 | ATR: 1.2%
  ├─ 📈 Tendencia: alcista
  ├─ MACD: ✅ Alcista
  └─ 🔊 Volumen: 2.1x

💡 RECOMENDACIÓN:
  └─ Comprar en zona $176.80-$178.50
     Vender 50% en Target 1, 50% en Target 2
     Stop estricto en $176.72
```

### Lunes (Actualización)
```
🔄 ACTUALIZACIÓN LUNES
🕐 18/11/2024 08:00 UTC
══════════════════════════════════════

🟢 1. AAPL - Score: 8.9/10
💰 Precio actual: $177.20
✅ ZONA DE COMPRA ACTIVA
💡 Entrada óptima: $176.80-$178.50
📍 🎯 Rebote alcista PREMIUM

🔴 2. MSFT - Score: 8.4/10
💰 Precio actual: $389.00
🔴 CANCELAR - Ya rebotó
💡 Precio superó entrada máxima (+2.3%)
```

## ⚙️ Configuración

### Capital por operación
Editar `config.json`:
```json
{
  "profile": {
    "capital_per_trade": 2500,  // Tu capital por operación
    "max_positions": 2           // Máx posiciones simultáneas
  }
}
```

### Ajustar sensibilidad
```json
{
  "scoring": {
    "green_threshold": 8.5,  // Bajar a 8.0 para más señales
    "yellow_threshold": 8.0   // Umbral mínimo
  },
  "targets": {
    "profit_target_pct": 7.0,  // Objetivo principal
    "stop_loss_pct": 1.0        // Stop loss
  }
}
```

## 📋 Estructura del Proyecto

```
swing-trading-analyzer/
├── agents/
│   ├── __init__.py
│   ├── data_agent.py          # Descarga y calcula indicadores
│   ├── analysis_agent.py      # Sistema de scoring y análisis
│   ├── selector_agent.py      # Filtros de calidad
│   └── report_agent.py        # Generación de informes
├── utils/
│   ├── __init__.py
│   ├── tickers_sp500.py
│   ├── tickers_nasdaq100.py
│   ├── tickers_stoxx50.py
│   ├── tickers_dax40.py
│   └── tickers_etfs.py
├── .github/
│   └── workflows/
│       └── run-agent.yml      # Automatización
├── config.json                # Configuración principal
├── orchestrator.py            # Coordinador principal
├── test_system.py             # Tests
├── requirements.txt
└── README.md
```

## 🎓 Estrategia de Trading

### Perfil recomendado
- **Capital**: €2,000 - €5,000
- **Posiciones**: 1-2 simultáneas
- **Capital/operación**: €2,500 - €3,000
- **Stop loss**: 1% (estricto)
- **Objetivo**: 5-10% en 3-5 días
- **Score mínimo**: 8+/10

### Gestión de riesgo
- ✅ **Never risk more than 1%** del capital por operación
- ✅ **Always use stop loss** (obligatorio)
- ✅ **Take profits**: 50% en Target 1, 50% en Target 2
- ✅ **Time limit**: Salir después de 5 días si no alcanza objetivo
- ✅ **No overlap**: Evitar tener más de 2 posiciones simultáneas

### Cuándo NO operar
- ❌ Score < 8.0
- ❌ Ratio R/R < 5:1
- ❌ Earnings próximos (< 7 días)
- ❌ Volatilidad ATR > 2%
- ❌ Volumen bajo (< 1.5x promedio)
- ❌ Mercado en pánico o euforia extrema

## 🔧 Troubleshooting

### Error: "No se pudieron descargar datos"
- **Causa**: Rate limiting de Yahoo Finance
- **Solución**: Esperar 5 minutos y reintentar

### Error: "Telegram credentials faltantes"
- **Causa**: Variables de entorno no configuradas
- **Solución**: Exportar TELEGRAM_TOKEN y TELEGRAM_CHAT_ID

### Warning: "No hay oportunidades esta semana"
- **Causa**: Mercado no presenta señales de calidad 8+
- **Solución**: Normal, no todas las semanas hay oportunidades. NUNCA forzar trades.

## 📊 Rendimiento Esperado

### Escenario conservador
- Operaciones/mes: 4
- Tasa de acierto: 60%
- Ganancia promedio: +6%
- Pérdida promedio: -1%
- **Retorno mensual: ~3.1%**
- **Anualizado: ~43%**

### Escenario realista
- Operaciones/mes: 6
- Tasa de acierto: 65%
- Ganancia promedio: +7%
- Pérdida promedio: -1%
- **Retorno mensual: ~4.2%**
- **Anualizado: ~60%**

## ⚠️ Disclaimer

Este sistema es una herramienta de análisis técnico. **NO es asesoramiento financiero.**

- ✅ Siempre haz tu propia investigación
- ✅ Solo invierte dinero que puedas permitirte perder
- ✅ Considera consultar a un asesor financiero profesional
- ✅ El rendimiento pasado no garantiza resultados futuros

## 📞 Soporte

- 📧 Issues: [GitHub Issues](https://github.com/tu-usuario/swing-trading-analyzer/issues)
- 📚 Docs: [Wiki](https://github.com/tu-usuario/swing-trading-analyzer/wiki)

## 📜 Licencia

MIT License - Ver [LICENSE](LICENSE)

---

**🎯 Happy Trading! 📈**
