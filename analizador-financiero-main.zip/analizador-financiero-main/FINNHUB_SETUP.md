# 📰 Configuración de Finnhub API

## ¿Qué es Finnhub?

Finnhub es una API financiera que proporciona:
- 📰 Noticias de empresas
- 📅 Calendario de earnings
- 💼 Insider transactions
- 📊 Datos fundamentales

## 🆓 Plan Gratuito

- **Límite**: 60 requests/minuto
- **Costo**: $0 (gratis)
- **Registro**: Simple, solo email

---

## 🚀 Paso a Paso

### 1. Crear cuenta en Finnhub

1. Ve a: https://finnhub.io/register
2. Regístrate con tu email
3. Verifica tu email

### 2. Obtener API Key

1. Una vez logueado, ve a: https://finnhub.io/dashboard
2. Copia tu **API Key** (aparece en el dashboard)
   - Ejemplo: `c123abc456def789ghi012jkl`

### 3. Configurar localmente

**Linux/Mac:**
```bash
export FINNHUB_API_KEY="tu_api_key_aqui"
```

**Windows:**
```cmd
set FINNHUB_API_KEY=tu_api_key_aqui
```

**O añadir a tu `.bashrc` / `.zshrc`:**
```bash
echo 'export FINNHUB_API_KEY="tu_api_key_aqui"' >> ~/.bashrc
source ~/.bashrc
```

### 4. Configurar en GitHub Actions

1. Ve a tu repositorio en GitHub
2. `Settings` → `Secrets and variables` → `Actions`
3. Click en `New repository secret`
4. Nombre: `FINNHUB_API_KEY`
5. Value: Tu API key
6. Click `Add secret`

---

## ✅ Verificar instalación

Ejecuta el test:

```bash
python test_finnhub.py
```

Deberías ver:
```
✅ Finnhub API configurada correctamente
📰 Obteniendo noticias de AAPL...
✅ 10 noticias obtenidas
```

---

## ⚙️ Habilitar/Deshabilitar

### Habilitar (en `config.json`):
```json
"sentiment": {
  "enabled": true,
  "finnhub_api_key_env": "FINNHUB_API_KEY",
  ...
}
```

### Deshabilitar:
```json
"sentiment": {
  "enabled": false,
  ...
}
```

Si está deshabilitado, el sistema funciona normalmente pero sin análisis de sentiment.

---

## 📊 Qué hace el Sentiment Agent

### 1. **Análisis de Noticias**
- Obtiene últimas 10 noticias de cada empresa
- Calcula sentiment score (-1 a +1)
- Detecta palabras clave positivas/negativas

### 2. **Calendario de Earnings**
- Verifica si hay earnings próximos
- Excluye valores con earnings en los próximos 7 días
- Evita volatilidad inesperada

### 3. **Insider Trading**
- Detecta si insiders están comprando/vendiendo
- Señal bullish: Insiders comprando
- Señal bearish: Insiders vendiendo

---

## 🔢 Rate Limits

Plan gratuito: **60 requests/minuto**

El sistema automáticamente:
- Espera 1 segundo entre requests
- No excede el límite
- Con 50 símbolos = ~1 minuto de análisis

---

## 💡 Ejemplo de Output

```
📰 FASE: ANÁLISIS DE SENTIMENT
══════════════════════════════════════════════════

[1/50] Analizando AAPL...
   ✅ 📈 Sentiment: 0.45 | Noticias: 10
      💼 Insiders: bullish

[2/50] Analizando TSLA...
   ❌ RECHAZADO: Earnings en 3 días

[3/50] Analizando NVDA...
   ✅ 📊 Sentiment: 0.12 | Noticias: 8
```

---

## ⚠️ Troubleshooting

### "API key no configurada"
- Verifica que la variable de entorno esté exportada
- Prueba: `echo $FINNHUB_API_KEY`

### "Rate limit exceeded"
- Espera 1 minuto
- El plan gratuito tiene 60 req/min

### "Invalid API key"
- Verifica que copiaste la key correctamente
- No debe tener espacios al inicio/final

---

## 🆘 Soporte

- Docs oficiales: https://finnhub.io/docs/api
- Status: https://status.finnhub.io/

---

## 🔄 Alternativa: Deshabilitado

Si no quieres usar Finnhub (o te quedaste sin requests):

En `config.json`:
```json
"sentiment": {
  "enabled": false
}
```

El sistema funciona perfectamente sin él, solo pierdes:
- Filtro de noticias negativas
- Detección de earnings próximos
- Insight de insider trading

**Recomendación**: Empieza con sentiment habilitado, si ves que no aporta valor o se acaban los requests, desactívalo.
